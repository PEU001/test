# exotic_cleanup.py — placeholder
# Reconstruisez les fichiers avec: python mb_rating_tag.py --rebuild
