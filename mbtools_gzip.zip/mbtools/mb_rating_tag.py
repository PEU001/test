
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mb_rating_tag.py (rebuild loader, gzip+tar support)
Usage:
  python mb_rating_tag.py --rebuild
Then run:
  python mb_rating_tag.py --help
"""
import os, sys, json, base64, gzip, tarfile, io
from pathlib import Path

PAYLOAD_FILE = 'rebuild_payload.json'
BANNER = 'mbtools — Mode reconstruction (gzip+tar)'

def _write(path: Path, data: bytes):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path,'wb') as f: f.write(data)

def do_rebuild():
    here = Path(__file__).resolve().parent
    p = here/PAYLOAD_FILE
    if not p.exists():
        print('[ERREUR] rebuild_payload.json introuvable'); sys.exit(2)
    payload = json.loads(p.read_text(encoding='utf-8'))
    if isinstance(payload, dict) and payload.get('encoding')=='tar-gzip-base64' and 'tar_gz_b64' in payload:
        tar_bytes = base64.b64decode(payload['tar_gz_b64'])
        with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode='r:gz') as tf:
            for m in tf.getmembers():
                data = tf.extractfile(m).read()
                _write(here/m.name, data)
                print(f"[OK] {m.name} ({len(data)} octets)")
        print('
Reconstruction par archive terminée.')
        return
    if 'files' in payload:
        for rel, b64 in payload['files'].items():
            raw = base64.b64decode(b64)
            # si gzip header, décompresser
            if raw[:2]==b'': raw = gzip.decompress(raw)
            _write(here/rel, raw)
            print(f"[OK] {rel} ({len(raw)} octets)")
        print('
Reconstruction par mapping terminée.')
        return
    print('[ERREUR] Payload non reconnu.')


def main(argv=None):
    argv = argv or sys.argv[1:]
    if '--rebuild' in argv:
        print(BANNER); return do_rebuild()
    print(BANNER)
    print('Placez rebuild_payload.json puis lancez --rebuild.')

if __name__=='__main__':
    main()
