# Placeholders — exécutez --rebuild pour générer les sources complètes.
